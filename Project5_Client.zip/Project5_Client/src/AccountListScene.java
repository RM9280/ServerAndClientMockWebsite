//Rebecca Mantione: Write the Account List 

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class AccountListScene extends SceneBasic {
	GridPane gridPane = null;
	Button adminMenu = null;
	Button logOut = null;
	int accountCount = 2;
	OutputTable accountListTable = new OutputTable("Username", "Account Type"); // Creates an output table to hold to list the																	// accounts
	VBox buttonBox = new VBox(); // Creates the VBox to hold the buttons

	/**
	 * Constructor to initialize the AccountListScene with a list of accounts.
	 *
	 */
	public AccountListScene() {

		BorderPane root = new BorderPane();
		scene = new Scene(root, 500, 300);

		Label title = new Label("Account List");
		root.setTop(title);
		title.setFont(Font.font(40));
		root.setAlignment(title, Pos.TOP_CENTER);

		gridPane = new GridPane();
		gridPane.setVgap(20);
		gridPane.setHgap(20);
		gridPane.add(accountListTable, 0, 0);
		root.setCenter(gridPane);

		// Adds the AdminMenu Button to the Scene
		buttonBox = addButton("AdminMenu", e -> SceneManager.setScene(SceneManager.SceneType.admin));

		// Adds the LogOut button to the Scene
		buttonBox = addButton("LogOut", e -> SceneManager.setScene(SceneManager.SceneType.login));

		gridPane.add(buttonBox, 2, accountCount);

		BorderPane.setMargin(gridPane, new Insets(20, 20, 20, 20));

	}

	public void addAccountLabel(String userName, String accountType) {
		accountListTable.addRow("Admin", "AdminAccount"); // Creates the Admin Account
		accountListTable.addRow("Client", "ClientAccount"); // Creates the Client Account
		accountCount++;
	}

	public void getAccountList() {
		try {
			Socket connection = SceneManager.getSocket();
			BufferedReader incoming = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			PrintWriter outgoing = new PrintWriter(connection.getOutputStream());
			outgoing.println("Send Account List");
			outgoing.flush();
			System.out.println("WAITING...");

			boolean done = false;

			try {
				String serverRes = incoming.readLine();
				System.out.println("RECEIVED:  " + serverRes);
				if ("Done".equals(serverRes)) {
					done = true;

				}
				String[] result = serverRes.split("%");
				String username = result[0];
				String accountType = result[1];
				addAccountLabel(username, accountType);
			} catch (IOException i) {
				System.out.println(i);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
