//Rebecca Mantione: Created the PlaceOrderScene

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class PlaceOrderScene extends SceneBasic {
	GridPane gridPaneInput;
	Button submit;
	Button cancel;
	int accountCount = 5;
	Label profileTxt;
	VBox root;
	GridPane gridInventory = new GridPane();
	OutputTable inventory = new OutputTable("Stock", "Description");
	VBox buttonBox = new VBox(); // VBox to hold the Buttons

	// Created the GUI for PlaceOrderScene
	public PlaceOrderScene() {
		super("Ordering");

		root = new VBox();
		scene = new Scene(root, 500, 300);

		// Set the title
		Label title = new Label("Ordering");
		root.getChildren().addAll(title);
		title.setFont(Font.font(40));
		BorderPane.setAlignment(title, Pos.TOP_CENTER);

		root.getChildren().addAll(gridInventory);

		// Set the column titles
		gridPaneInput = new GridPane();
		gridPaneInput.setVgap(20);
		gridPaneInput.setHgap(20);

		// created the labels and textfields
		UserInput stockInput = new UserInput("Stock #");
		UserInput quantityInput = new UserInput("Quantity");

		// create the buttons and set their action
		buttonBox = addButton("Submit", e -> sendOrder(stockInput, quantityInput));
		buttonBox = addButton("Cancel", e -> SceneManager.setScene(SceneManager.SceneType.customer));

		// Put it on the GUI
		profileTxt = new Label();

		root.getChildren().addAll(inventory);

		gridPaneInput.add(stockInput, 0, 1);

		gridPaneInput.add(quantityInput, 0, 2);

		gridPaneInput.add(buttonBox, 0, 4);

		root.getChildren().addAll(gridPaneInput);

		BorderPane.setMargin(gridPaneInput, new Insets(20, 20, 20, 20));
	}

	// Reads the incoming stocknumber and description and puts it onto the GUI
	public void getInventory() {
		System.out.println("Starting get Inventory");
		Socket connection = SceneManager.getSocket();
		try {

			BufferedReader incoming = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			PrintWriter outgoing = new PrintWriter(connection.getOutputStream());
			outgoing.println("Inventory");// indication that it wants to call send inventory
			outgoing.flush();
			System.out.println("WAITING...");
			try {

				int row = 1;
				String stockNumber = incoming.readLine();// reads incoming line
				System.out.println("starting while loop");
				while (!stockNumber.equals("Done")) {// makes sure it is not the end
					System.out.println(stockNumber);
					String description = incoming.readLine();
					inventory.addRow(stockNumber, description);

					row++;// which row to place it on
					stockNumber = incoming.readLine();// reads incoming line

				}

			} catch (IOException i) {
				System.out.println(i);
			}
		} catch (IOException i) {
			System.out.println(i);
		}

	}

	// reads the orders in and saves it to a binary file
	public void sendOrder(UserInput stockTextField, UserInput quantityTextField) {
		Socket connection = SceneManager.getSocket();
		try {

			// gets the connection
			PrintWriter outgoing = new PrintWriter(connection.getOutputStream());
			outgoing.println("Order");// indicates that it is calling getOrder
			System.out.println("WAITING...");

			// reads in from the TextFields
			String stockTextFieldInput = stockTextField.getText();
			String quantityTextFieldInput = quantityTextField.getText();

			System.out.println(stockTextFieldInput);
			System.out.println(quantityTextFieldInput);

			// sends them to be saved to the binary file
			outgoing.println(stockTextFieldInput);
			outgoing.println(quantityTextFieldInput);
			outgoing.flush();

		} catch (IOException i) {
			System.out.println(i);
		}

	}
}
