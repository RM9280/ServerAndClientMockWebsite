//Rebecca Mantione: Creates a horizontal bar of buttons

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;

public class ButtonBar extends HBox {

	Button button;

	public ButtonBar() {

	}

	// Creates the button using a string read in, the adds the acction, and adds it
	// to the scene
	public void addButton(String txt, EventHandler<ActionEvent> func) {
		button = new Button(txt);
		button.setOnAction(func);
		getChildren().addAll(button);

	}

}
