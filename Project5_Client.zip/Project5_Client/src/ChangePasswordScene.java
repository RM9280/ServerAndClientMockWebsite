
//Rebecca Mantione: Scene for changing the password

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ChangePasswordScene extends SceneBasic {
	private PasswordInput oldPassword; // Field for entering the old password.
	private PasswordInput newPassword; // Field for entering the new password.
	private Account currentAccount; // The current account for which the password is being changed.
	private BorderPane root; // Creates the instance of the borderpane
	VBox buttonBox = new VBox(); // VBox to hold the buttons

	/**
	 * Initializes the ChangePasswordScene.
	 */
	public ChangePasswordScene() {
		root = new BorderPane();
		scene = new Scene(root, 500, 300);

		Label title = new Label("Change Password");
		root.setTop(title);
		title.setFont(Font.font(40));
		root.setAlignment(title, Pos.TOP_CENTER);

		GridPane gridPane = new GridPane();
		gridPane.setVgap(20);
		gridPane.setHgap(20);
		Label oldPass = new Label("Enter Old Password");
		Label newPass = new Label("Enter New Password");

		// Uses PasswordInput to create two password field text boxes
		oldPassword = new PasswordInput("password");
		newPassword = new PasswordInput("password");

		gridPane.add(oldPass, 0, 0);
		gridPane.add(newPass, 1, 0);
		gridPane.add(oldPassword, 0, 1);
		gridPane.add(newPassword, 1, 1);

		root.setCenter(gridPane);

		// Adds Change Password button
		buttonBox = addButton("Change Password", e -> change());
		// Adds client Menu button
		buttonBox = addButton("Login Menu", e -> SceneManager.setScene(SceneManager.SceneType.login));

		gridPane.add(buttonBox, 2, 2);

		BorderPane.setMargin(gridPane, new Insets(20, 20, 20, 20));

	}

	/**
	 * Performs the password change operation.
	 */
	public void change() {

		try {
			Socket connection = SceneManager.getSocket();
			BufferedReader incoming = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			PrintWriter outgoing = new PrintWriter(connection.getOutputStream());
			outgoing.println("Change Password");
			outgoing.println(oldPassword.getText());
			outgoing.println(newPassword.getText());
			outgoing.flush();
			System.out.println("WAITING...");
			try {
				String serverRes = incoming.readLine();
				System.out.println("RECEIVED:  " + serverRes);
				if (serverRes.equals("Done")) {
					SceneManager.setScene(SceneManager.SceneType.login);
				} else {
					Label invalid = new Label(serverRes);
					root.setBottom(invalid);
				}

			} catch (IOException i) {
				System.out.println(i);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Sets the current account for password change.
	 *
	 * @param currentAccount The current account.
	 */
	public void setAccount(Account currentAccount) {
		this.currentAccount = currentAccount;
	}
}
