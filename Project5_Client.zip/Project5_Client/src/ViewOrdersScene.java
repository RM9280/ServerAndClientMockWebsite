//Rebecca Mantione: Creates the View Order Scene

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class ViewOrdersScene extends SceneBasic {

	GridPane gridPane = null;
	Button menu = null;
	int orderCount = 1;
	OutputTable inventory = new OutputTable("Stock", "Description", "Quantity"); // Output table to display the stock
																					// number, description, and quantity
	VBox buttonBox = new VBox(); // VBox to hold the buttons

	public ViewOrdersScene() {
		super("View Order");

		System.out.println("Got here");
		BorderPane root = new BorderPane();
		scene = new Scene(root, 500, 300);

		Label title = new Label("View Orders");
		root.setTop(title);
		title.setFont(Font.font(40));
		BorderPane.setAlignment(title, Pos.TOP_CENTER);

		gridPane = new GridPane();
		gridPane.setVgap(20);
		gridPane.setHgap(20);

		inventory.addRow("45", "Thingamajig", "5");// Creates two items for orders and adds it to the output table
		inventory.addRow("46", "thingamajig", "6");

		gridPane.add(inventory, 0, 0);

		root.setCenter(gridPane);

		// Adds the Reutrn to Menu Button
		buttonBox = addButton("Return to Menu", e -> SceneManager.setScene(SceneManager.SceneType.customer));

		gridPane.add(buttonBox, 2, orderCount);
		BorderPane.setMargin(gridPane, new Insets(20, 20, 20, 20));

	}

	public void addOrdersLabel(int stock, String description, int quantity) {
		inventory.addRow("45", "Thingamajig", "5");// Creates two items for orders and adds it to the output table
		inventory.addRow("46", "thingamajig", "6");

		orderCount++;
	}

	public void getOrders() {

	}
}
