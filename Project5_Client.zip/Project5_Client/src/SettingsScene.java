//Rebecca Mantion: Setting Scene

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class SettingsScene extends SceneBasic {

	private ArrayList<Account> accounts; // List of user accounts.
	private Label statusLbl; // Label to display login status.
	private UserInput hostLabel = new UserInput("Host"); // Creates the text field for host
	private UserInput portLabel = new UserInput("Port"); // Creates the text field for port

	/**
	 * Initializes the LoginScene with a list of accounts.
	 * 
	 */
	public SettingsScene() {
		super("Setting Scene");
		this.accounts = accounts;

		BorderPane root = new BorderPane();
		scene = new Scene(root, 500, 300);

		Label title = new Label("Setting Scene");
		title.setFont(Font.font(40));
		statusLbl = new Label();
		root.setTop(title);
		root.setAlignment(title, Pos.TOP_CENTER);
		root.setBottom(statusLbl);

		GridPane gridPane = new GridPane();
		gridPane.setVgap(20);
		gridPane.setHgap(20);
		gridPane.add(hostLabel, 0, 0);
		gridPane.add(portLabel, 0, 1);

		root.setCenter(gridPane);
		BorderPane.setMargin(gridPane, new Insets(20, 20, 20, 20));

		// Creates the ButtonBar to hold the buttons
		ButtonBar settingSceneButtons = new ButtonBar();
		// Creates the Apply Button
		settingSceneButtons.addButton("Apply", e -> apply());
		// Creates the cancel Button
		settingSceneButtons.addButton("Cancel", e -> cancel());
		// Creates the chat Button
		settingSceneButtons.addButton("Chat", e -> {
			CustomerChat chats = new CustomerChat();
			chats.start(new Stage());
		});

		gridPane.add(settingSceneButtons, 0, 2);

	}

	/**
	 * Performs the login operation.
	 */
	public void apply() {
		int port = Integer.valueOf(portLabel.getText());
		String host = hostLabel.getText();
		try {
			Socket connection = new Socket(host, port);
			SceneManager.setSocket(connection);
			SceneManager.setScene(SceneManager.SceneType.login);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void cancel() {
		SceneManager.setScene(SceneManager.SceneType.login);

	}
}
