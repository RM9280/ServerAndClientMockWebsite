//Rebecca Mantione

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

public class UserInput extends HBox {

	private Label label;
	protected TextField textfield = new TextField();

	// creates a label for the textfield
	public UserInput(String labelText) {
		System.out.println("made it");
		label = new Label(labelText);
		getChildren().addAll(label, textfield);
		textfield.getText();

	}

	// creates the text field and gets the input
	public String getText() {
		System.out.println("Got Text");
		String textIn = textfield.getText();
		return textIn;
	}

}
