//Rebecca Mantion: Creates a Password Input

import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;

public class PasswordInput extends UserInput {

	// creates a label and passwordfield() then adds it to the Scene
	public PasswordInput(String labelText) {
		super(labelText);
		getChildren().remove(textfield);
		textfield = new PasswordField();
		getChildren().addAll(textfield);
	}

}
