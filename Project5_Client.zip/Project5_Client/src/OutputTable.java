//Rebecca Mantione: Creates the output table

import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

public class OutputTable extends GridPane {

	private int row = 1;

	// Creates the heading for the output table
	public OutputTable(String... headers) {
		clearData(); // clears the data
		Label label;
		for (int i = 0; i < headers.length; i++) {
			label = new Label(headers[i]);
			add(label, i, 0);
		}
	}

	// Creates the values inside the output table
	public void addRow(String... values) {
		for (int i = 0; i < values.length; i++) {
			Label labelValue = new Label(values[i]);
			add(labelValue, i, row);
		}
		row++;
	}

	// Clears the data
	public void clearData() {
		row = 1;
	}

}
