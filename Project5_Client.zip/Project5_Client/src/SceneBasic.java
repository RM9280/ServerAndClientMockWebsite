
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public abstract class SceneBasic {

	protected Scene scene; // The JavaFX scene object.
	protected String titleText; // The title text for the scene.
	protected VBox root = new VBox();
	Button button;
	protected HBox hBox = new HBox();

	/**
	 * Default constructor.
	 */
	public SceneBasic() {

	}

	/**
	 * Constructor to initialize the SceneBasic with a title.
	 *
	 * @param titleText The title text for the scene.
	 */
	public SceneBasic(String titleText) {
		this.titleText = titleText;
	}

	/**
	 * Get the JavaFX Scene object.
	 *
	 * @return The JavaFX Scene object.
	 */
	public Scene getScene() {
		return scene;
	}

	/**
	 * Get the title text for the scene.
	 *
	 * @return The title text.
	 */
	public String getTitleText() {
		return titleText;
	}

	public void logout() {

	}

	// Rebecca Mantione; addButton method
	public VBox addButton(String txt, EventHandler<ActionEvent> func) {
		button = new Button(txt); // adds the button text
		button.setOnAction(func); // adds the action to the button
		root.getChildren().addAll(button); // adds it to the root
		return root;
	}

}
