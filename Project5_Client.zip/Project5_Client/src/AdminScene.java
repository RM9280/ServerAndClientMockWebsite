
//Rebecca Mantione: Creates the Admin Scene using addButton()
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

public class AdminScene extends SceneBasic {

	private AdminAccount currentAccount; // The current administrator account.
	VBox buttonBox = new VBox(); // Creates a VBox to store the buttons in

	public AdminScene() {
		super("Administrator Menu"); // Title of the Menu
		BorderPane root = new BorderPane();
		scene = new Scene(root, 500, 300);

		Label title = new Label("Administrator Menu");
		root.setTop(title);
		title.setFont(Font.font(40));
		root.setAlignment(title, Pos.TOP_CENTER);

		GridPane gridPane = new GridPane();
		gridPane.setVgap(20);
		gridPane.setHgap(20);

		//Adds the List Accounts button
		buttonBox = addButton("List Accounts", e -> SceneManager.setScene(SceneManager.SceneType.accountList));

		//Adds the Change Password button
		buttonBox = addButton("Change Password", e -> SceneManager.setScene(SceneManager.SceneType.changePassword));

		//Adds the List Logout button
		buttonBox = addButton("Logout", e -> SceneManager.setScene(SceneManager.SceneType.login));

		gridPane.add(buttonBox, 0, 0);

		BorderPane.setMargin(gridPane, new Insets(20, 20, 20, 20));

		root.setCenter(gridPane);
	}

}
